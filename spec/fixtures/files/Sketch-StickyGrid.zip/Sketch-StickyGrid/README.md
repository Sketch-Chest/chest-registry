# StickyGrid

Sketch plugin to make paths be snapped to grid.

![](https://raw.githubusercontent.com/uetchy/Sketch-StickyGrid/master/assets/readme_images/stickygrid.gif)

## Installation

1. [Download the plugin](https://github.com/uetchy/Sketch-StickyGrid/archive/master.zip)
2. Unzip the archive
3. Place the folder into your Sketch Plugins folder.

## Usage

### Snap to Grid `ctrl` + `⌘` + `G`
